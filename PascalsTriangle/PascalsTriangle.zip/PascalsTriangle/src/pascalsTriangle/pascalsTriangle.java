
package pascalsTriangle;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class pascalsTriangle {
	
	// console debug option
	public static boolean console = true;	// Debug - false to turn off

	/**
	 * @param args
	 */

	public static void main(String[] args) {
		
		GetPascalTriangleParams g = new GetPascalTriangleParams();
	}
	
}


